// 변수 선언하기
// var
// a라는 숫자 변수에 값 10을 넣기
var a = 10;
console.log(a);

// b라는 문자 변수에 "javascript"를 넣기
var b="javascript";
console.log(b);

// c boolean true, false
var c=true;
console.log(c);

var d;
console.log(d);

// console.log(aa);
// a 재할당
a =5;
console.log(a);

var a=3;
console.log(a);

// const 상수 선언
// 재선언, 재할당을 할수 없다
const bb=50;
console.log(bb);

// bb=33;
// console.log(bb);

// const bb=33;
// console.log(bb);

// let
// 재선언을 할수 없다. 재할당 가능
let aaa=10;
console.log(aaa);

aaa=20;
console.log(aaa);
// let aaa=20;
// console.log(aaa)