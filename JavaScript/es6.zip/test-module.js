import { arr, getName } from "./sample-module.js";

console.log(arr);

export function init(){
    console.log(getName());
}