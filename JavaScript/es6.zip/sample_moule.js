let uName = "module man";
export let arr=[10,20,30,40,50];

export function getName(){
    return uName;
}