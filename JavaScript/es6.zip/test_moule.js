import {arr,getName} from"./sample_moule.js";
console.log(arr);

export function init(){
    console.log(getName());
}