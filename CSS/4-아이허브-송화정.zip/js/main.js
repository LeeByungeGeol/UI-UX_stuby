window.addEventListener("load", function () {
  var hamBtn = document.querySelector(".hamBtn>a");
  var closeBtn = document.querySelector(".closeBtn")
  var menu = document.querySelector("#nav");

  //햄버거 버튼을 클릭하면
   //#nav right :0 이 되도록
  hamBtn.addEventListener("click", function () {
    // menu.style.right=0;
    closeBtn.style.display="block";
    leftAnimate();
  });

  closeBtn.addEventListener("click",function(){
    //   menu.style.right="-100%";
    closeBtn.style.display="none";
    rightAnimate();
   })

    var start=100;
    var ani;
    function leftAnimate(){
        start -=2;
        menu.style.right = -start+"%";
        if(start>0){
            ani=window.requestAnimationFrame(leftAnimate)
        }          
    }
    function rightAnimate(){
        start +=2;
        menu.style.right = -start+"%";
        if(start<100){
            ani=window.requestAnimationFrame(rightAnimate)
        } 
    }

});
