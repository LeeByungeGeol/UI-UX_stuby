$(function(){
    //현재 시간부터 12시간뒤
    var datetime = new Date().getTime()/1000 + (86400*3) +1;
    console.log(datetime);

    var flipdown = new FlipDown(datetime);
    flipdown.start();
})